# HKR Document Management System
Modern, multi-town work software for Admins and Updaters.