import React from 'react';
import background from '../../public/background.jpg';

export default function Dashboard() {
  return (
    <div style={{
      backgroundImage: `url(${background})`,
      backgroundSize: 'cover',
      height: '100vh',
      padding: '20px',
      color: 'white'
    }}>
      <h1 className="text-3xl font-bold">Welcome to HKR Dashboard</h1>
      <p>Choose a section: Offline Document or Kaveri 2.0</p>
    </div>
  );
}
