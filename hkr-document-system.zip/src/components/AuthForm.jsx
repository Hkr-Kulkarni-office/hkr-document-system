import React from 'react';

export default function AuthForm() {
  return (
    <div className="auth-form">
      <h2>Login</h2>
      <input type="text" placeholder="Username" />
      <input type="password" placeholder="Password" />
      <button>Login</button>
    </div>
  );
}
